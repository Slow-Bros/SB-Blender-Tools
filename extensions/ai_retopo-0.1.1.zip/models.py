# SPDX-License-Identifier: GPL-3.0-or-later
"""Registry der Retopologie-Modelle der Scenario API.

Die Tabelle steht in models.json neben diesem Modul, damit ein Modell ohne
Code-Aenderung ergaenzt oder korrigiert werden kann.

Jedes Modell hat eigene Parameternamen und eine eigene Art, die Polygondichte
zu steuern. Zwei Modelle nehmen eine echte Zielzahl entgegen, eines kennt nur
drei Stufen. Das Panel richtet sich nach `density` des gewaehlten Modells.

Quelle: docs.scenario.com, Endpunkt /v1/generate/custom/{model_id}.
"""

import json
import os
import zlib

from .log import log

# Art der Dichtesteuerung
DENSITY_LEVEL = "level"  # nur low / medium / high
DENSITY_COUNT = "count"  # echte Zielzahl an Faces

# Interne, modellunabhaengige Werte fuer den Topologie-Typ
QUADS = "quads"
TRIS = "tris"

BUNDLED_FILE = os.path.join(os.path.dirname(__file__), "models.json")

# Upload-Limit fuer Modelle, deren Doku keines nennt (Meshy). Das groesste
# dokumentierte Limit: Hunyuan nimmt 200 MB, Tripo 150 MB. Die Pruefung vor
# dem Upload passiert im Client, das Panel warnt schon vorher.
DEFAULT_UPLOAD_LIMIT_MB = 200

REQUIRED_KEYS = ("key", "id", "label", "density", "file_param",
                 "polygon_param", "polygon_values")

# Platzhalter, falls models.json fehlt oder unbrauchbar ist: Panel und Enum
# haben damit etwas anzuzeigen, das Add-on registriert sich trotzdem. Einen
# Job startet der Operator damit nicht (poll prueft LOAD_ERROR), die id ist
# bewusst leer.
FALLBACK_MODELS = [
    {
        "key": "registry_broken",
        "id": "",
        "label": "Model list unusable",
        "description": "models.json could not be read, see the panel",
        "density": DENSITY_LEVEL,
        "file_param": "file3d",
        "polygon_param": "polygonType",
        "polygon_values": {QUADS: "quadrilateral", TRIS: "triangle"},
        "level_param": "faceLevel",
        "upload_limit_mb": DEFAULT_UPLOAD_LIMIT_MB,
        "extra": {},
    },
]

MODELS = []
LOAD_ERROR = ""


def _parse_count_range(model_key, raw):
    """Normalisiert count_range auf {QUADS: (min, max), TRIS: (min, max)}.

    In der Datei steht entweder ein Paar [min, max] fuer beide Polygontypen
    oder ein Objekt mit einem Paar je Typ. Tripo etwa nimmt fuer Quads nur
    bis 10.000 Faces, fuer Dreiecke bis 20.000; ein Job mit 20.000 Quads
    scheitert erst nach dem Upload und kostet trotzdem Credits.
    """
    if isinstance(raw, dict):
        pairs = {pk: raw.get(pk) for pk in (QUADS, TRIS)}
    else:
        pairs = {pk: raw for pk in (QUADS, TRIS)}
    result = {}
    for pk, pair in pairs.items():
        if (not isinstance(pair, (list, tuple)) or len(pair) != 2
                or not all(isinstance(v, int) and not isinstance(v, bool) for v in pair)):
            raise ValueError(f"'{model_key}' count_range for '{pk}' is not [min, max]")
        lo, hi = pair
        if lo > hi:
            raise ValueError(f"'{model_key}' count_range for '{pk}' has min above max")
        result[pk] = (lo, hi)
    return result


def _validate(entry):
    for key in REQUIRED_KEYS:
        if key not in entry:
            raise ValueError(f"model entry is missing '{key}'")
    if entry["density"] not in (DENSITY_LEVEL, DENSITY_COUNT):
        raise ValueError(f"unknown density '{entry['density']}' in '{entry['key']}'")

    values = entry["polygon_values"]
    for pk in (QUADS, TRIS):
        if pk not in values:
            raise ValueError(f"'{entry['key']}' has no polygon value for '{pk}'")

    if entry["density"] == DENSITY_COUNT:
        for key in ("count_param", "count_range"):
            if key not in entry:
                raise ValueError(f"'{entry['key']}' is missing '{key}'")
        entry["count_range"] = _parse_count_range(entry["key"], entry["count_range"])
    else:
        entry.setdefault("level_param", "faceLevel")

    limit = entry.setdefault("upload_limit_mb", DEFAULT_UPLOAD_LIMIT_MB)
    if isinstance(limit, bool) or not isinstance(limit, (int, float)) or limit <= 0:
        raise ValueError(f"'{entry['key']}' upload_limit_mb is not a positive number")

    entry.setdefault("description", entry["label"])
    entry.setdefault("extra", {})
    return entry


def _read(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    entries = data.get("models") if isinstance(data, dict) else data
    if not isinstance(entries, list) or not entries:
        raise ValueError("no 'models' list in file")
    result = []
    seen = set()
    numbers = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("model entry is not an object")
        entry = _validate(dict(entry))
        if entry["key"] in seen:
            raise ValueError(f"duplicate model key '{entry['key']}'")
        seen.add(entry["key"])
        number = enum_number(entry["key"])
        if number in numbers:
            raise ValueError(f"enum number of '{entry['key']}' collides with '{numbers[number]}'")
        numbers[number] = entry["key"]
        result.append(entry)
    return result


def load():
    """Laedt die Registry aus models.json, mit eingebautem Notnagel."""
    global MODELS, LOAD_ERROR
    try:
        MODELS = _read(BUNDLED_FILE)
        LOAD_ERROR = ""
        return MODELS
    except Exception as e:  # noqa: BLE001 - eine kaputte Datei darf nichts blockieren
        MODELS = [dict(m) for m in FALLBACK_MODELS]
        LOAD_ERROR = str(e)
        log(f"Model registry unusable: {e}")
        return MODELS


def get(key):
    """Modell-Spezifikation zu einem Schluessel, Fallback auf das erste Modell.

    MODELS ist nie leer: _read lehnt eine leere Liste ab und load() setzt
    sonst den Notnagel ein.
    """
    for spec in MODELS:
        if spec["key"] == key:
            return spec
    return MODELS[0]


def enum_number(key):
    """Stabile Nummer eines Modells fuer die EnumProperty.

    Blender speichert die Auswahl als Integer in der .blend-Datei. Ohne feste
    Nummer waere das der Listenindex, und ein Umsortieren von models.json
    wuerde in gespeicherten Szenen still ein anderes Modell auswaehlen. Die
    CRC des Schluessels ist deterministisch und braucht kein Feld in der Datei;
    _read prueft, dass keine zwei Schluessel dieselbe Nummer bekommen.
    """
    return zlib.crc32(key.encode()) & 0x7FFFFFFF


def enum_items():
    """Items fuer die EnumProperty im Panel: (id, name, description, icon, number)."""
    return tuple((m["key"], m["label"], m["description"], "NONE", enum_number(m["key"]))
                 for m in MODELS)


def uses_count(spec):
    return spec["density"] == DENSITY_COUNT


def count_range(spec, polygon_key):
    """(min, max) der Zielzahl fuer diesen Polygontyp, None bei Stufen-Modellen."""
    if not uses_count(spec):
        return None
    if polygon_key not in (QUADS, TRIS):
        raise ValueError(f"unknown topology key: {polygon_key}")
    return spec["count_range"][polygon_key]


def clamp_count(spec, value, polygon_key):
    """Zielzahl in den Bereich zwingen, den das Modell fuer diesen Polygontyp erlaubt."""
    bounds = count_range(spec, polygon_key)
    if bounds is None:
        return value
    lo, hi = bounds
    return max(lo, min(hi, int(value)))


def count_range_label(spec, polygon_key):
    bounds = count_range(spec, polygon_key)
    if bounds is None:
        return ""
    return f"{bounds[0]:,} to {bounds[1]:,}"


def upload_limit_bytes(spec):
    """Groesste Datei, die dieses Modell annimmt."""
    return int(spec["upload_limit_mb"] * 1024 * 1024)


def build_request(spec, asset_id, polygon_key, *, face_level=None, target_faces=None):
    """Baut den Request-Body fuer /v1/generate/custom/{id}.

    polygon_key ist QUADS oder TRIS und wird auf den Wert des jeweiligen
    Modells abgebildet. Je nach Modell wird entweder face_level oder
    target_faces verwendet; ein count-Modell braucht target_faces.
    """
    if polygon_key not in (QUADS, TRIS):
        raise ValueError(f"unknown topology key: {polygon_key}")

    body = {spec["file_param"]: asset_id}
    body[spec["polygon_param"]] = spec["polygon_values"][polygon_key]

    if uses_count(spec):
        body[spec["count_param"]] = clamp_count(spec, target_faces, polygon_key)
    else:
        body[spec["level_param"]] = face_level or "medium"

    body.update(spec.get("extra", {}))
    return body


# Am Ende, weil _read auf enum_number zugreift
load()
