# SPDX-License-Identifier: GPL-3.0-or-later
"""N-Panel (Sidebar) im 3D-Viewport, Tab 'SBTools'."""

import textwrap

import bpy

from . import history, mesh_io, models, operators, preferences

STATUS_ICONS = {
    history.STATUS_RUNNING: "SORTTIME",
    history.STATUS_FINISHED: "CHECKMARK",
    history.STATUS_FAILED: "ERROR",
    history.STATUS_CANCELLED: "X",
}


def _pretty_time(started):
    """'2026-09-09T15:11:34' als '2026-09-09 15:11'."""
    return started.replace("T", " ")[:16] if started else "unknown"


def _pretty_size(size_mb):
    """Groesse des Ergebnisses. Unter einem MB in KB, sonst waere ein kleines
    Mesh dieselbe '0.00 MB' wie ein nie heruntergeladenes."""
    if size_mb >= 1.0:
        return f"{size_mb:.2f} MB"
    if size_mb > 0.0:
        return f"{size_mb * 1024:.0f} KB"
    return "size unknown"


def _draw_upload_size(box, mesh, spec, settings):
    """Upload-Limit und Empfehlung unter der Face-Zahl.

    Erst die Pflicht: sprengt der Upload das Limit des Modells, steht das hier
    mit der Face-Zahl, auf die die Pre-Decimation mindestens gehen muss.
    Geschaetzt aus den Zaehlern des Meshes, wie es exportiert wuerde: mit
    Pre-Decimation zaehlt deren Ziel.

    Dann die Kuer: der Bereich, der den Modellen erfahrungsgemaess am besten
    bekommt (mesh_io.recommended_upload_faces), nach oben auf das Limit
    gekappt. Ein Haken statt des Info-Symbols, wenn die Pre-Decimation schon
    darin liegt.
    """
    counts = (len(mesh.vertices), len(mesh.loops), len(mesh.polygons))
    limit = models.upload_limit_bytes(spec)
    decimate = settings.pre_decimate_target if settings.pre_decimate else 0
    size = mesh_io.estimate_upload_bytes(*counts, decimate_target=decimate)
    fit = mesh_io.faces_within_upload_limit(*counts, limit)
    if size > limit:
        # Kurz genug fuer die Sidebar-Breite; welches Modell das Limit setzt,
        # steht direkt darunter in der Modellwahl
        box.label(text=f"Upload about {size / 1024 / 1024:.0f} MB, limit is {limit / 1024 / 1024:.0f} MB",
                  icon="ERROR")
        box.label(text=f"Reduce to at least {fit:,} faces (Pre-Decimation)", icon="BLANK1")

    advice = mesh_io.recommended_upload_faces(counts[2], max_faces=fit)
    if advice is None:
        return
    low, high = advice
    within = settings.pre_decimate and low <= settings.pre_decimate_target <= high
    # Prozent aus den Zahlen selbst, denn Boden und Limit verschieben sie
    lo_pct, hi_pct = round(low / counts[2] * 100), round(high / counts[2] * 100)
    if low == high:
        text = f"Recommended upload: about {high:,} faces"
        share = f"{hi_pct} % of the source, via Pre-Decimation"
    else:
        text = f"Recommended upload: {low:,} to {high:,} faces"
        share = f"{lo_pct} to {hi_pct} % of the source, via Pre-Decimation"
    box.label(text=text, icon="CHECKMARK" if within else "INFO")
    box.label(text=share, icon="BLANK1")


class VIEW3D_PT_sb_ai_retopo(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "SBTools"
    bl_label = "AI Retopo"
    # Der Tab ist allen SBTools-Add-ons gemeinsam; bl_order haelt dieses Panel oben
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        settings = context.scene.sb_ai_retopo
        obj = context.active_object

        if models.LOAD_ERROR:
            box = layout.box()
            box.alert = True
            box.label(text="Model list unusable, fix models.json and restart", icon="ERROR")
            box.label(text=models.LOAD_ERROR[:60], icon="BLANK1")

        api_key, api_secret = preferences.get_credentials(context)
        if not api_key or not api_secret:
            box = layout.box()
            box.label(text="Scenario API key is missing", icon="ERROR")
            box.operator("preferences.addon_show", text="Add-on Preferences").module = __package__

        spec = models.get(settings.model)

        # -- Object -------------------------------------------------------
        box = layout.box()
        if obj is not None and obj.type == "MESH":
            box.label(text=obj.name, icon="MESH_DATA")
            box.label(text=f"{len(obj.data.polygons):,} faces")
            _draw_upload_size(box, obj.data, spec, settings)
        else:
            box.label(text="No mesh selected", icon="INFO")
        if context.mode != "OBJECT":
            box.label(text="Object Mode only", icon="ERROR")

        # -- Settings -----------------------------------------------------
        col = layout.column(align=True)
        col.label(text="AI Model")
        col.prop(settings, "model", text="")

        col.separator()
        col.label(text="Target Polygons")
        if models.uses_count(spec):
            col.prop(settings, "target_faces", text="")
            limited = models.clamp_count(spec, settings.target_faces, settings.polygon_type) != settings.target_faces
            col.label(
                text=f"Model accepts {models.count_range_label(spec, settings.polygon_type)}",
                icon="ERROR" if limited else "NONE",
            )
        else:
            col.prop(settings, "face_level", expand=True)
            col.label(text="This model has levels only, no target count")

        col.separator()
        col.label(text="Polygons")
        col.prop(settings, "polygon_type", expand=True)
        col.separator()
        col.prop(settings, "remove_fragments")
        col.prop(settings, "hide_source")

        row = col.row(align=True)
        row.prop(settings, "pre_decimate")
        sub = row.row(align=True)
        sub.enabled = settings.pre_decimate
        sub.prop(settings, "pre_decimate_target", text="")

        layout.separator()

        # -- Action and status --------------------------------------------
        layout.operator("sb.ai_retopo", icon="MOD_REMESH", text="Start AI Retopology")

        # Ein Balken je Job dieser Datei. Jobs anderer Dateien laufen im
        # Hintergrund weiter und werden nur gezaehlt: ihr Ergebnis gehoert
        # nicht hierher.
        for job in operators.jobs_for_open_file():
            col = layout.column(align=True)
            col.label(text=f"{job.source_name} ({job.model_label})", icon="MESH_DATA")
            row = col.row(align=True)
            row.progress(text=job.status or "Running ...", factor=job.progress, type="BAR")
            row.operator("sb.ai_retopo_cancel", text="", icon="CANCEL").token = job.token
        others = operators.other_jobs_count()
        if others:
            layout.label(text=f"{others} job(s) running in other projects", icon="TIME")

        if settings.last_result:
            layout.label(text=settings.last_result, icon="CHECKMARK")
        if settings.last_warning:
            box = layout.box()
            for i, line in enumerate(textwrap.wrap(settings.last_warning, 42)):
                box.label(text=line, icon="ERROR" if i == 0 else "BLANK1")
        if settings.last_error:
            box = layout.box()
            box.alert = True
            for i, line in enumerate(textwrap.wrap(settings.last_error, 42)):
                box.label(text=line, icon="ERROR" if i == 0 else "BLANK1")


class VIEW3D_UL_sb_ai_retopo_history(bpy.types.UIList):
    """Eine Zeile pro Job: Name wie im Outliner, Modell, Status als Icon."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_prop, index):
        row = layout.row(align=True)
        row.label(text=item.name or item.job_id,
                  icon=STATUS_ICONS.get(item.status, "MESH_DATA"))
        sub = row.row()
        sub.alignment = "RIGHT"
        sub.label(text=item.model)


class VIEW3D_PT_sb_ai_retopo_history(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "SBTools"
    bl_parent_id = "VIEW3D_PT_sb_ai_retopo"
    bl_label = "History"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        settings = context.scene.sb_ai_retopo
        wm = context.window_manager

        row = layout.row(align=True)
        row.prop(settings, "history_this_project")
        row.operator("sb.ai_retopo_history_refresh", text="", icon="FILE_REFRESH")

        if not wm.sb_ai_retopo_history:
            if settings.history_this_project and not bpy.data.filepath:
                layout.label(text="No jobs in this unsaved file yet", icon="INFO")
            else:
                layout.label(text="No jobs yet", icon="INFO")
            return

        layout.template_list("VIEW3D_UL_sb_ai_retopo_history", "",
                             wm, "sb_ai_retopo_history",
                             wm, "sb_ai_retopo_history_index", rows=4)

        item = history.selected(context)
        if item is None:
            return

        box = layout.box()
        box.label(text=_pretty_time(item.started), icon="TIME")
        box.label(text=item.model or "unknown model", icon="MOD_REMESH")
        box.label(text=item.status or "unknown",
                  icon=STATUS_ICONS.get(item.status, "QUESTION"))
        box.label(text=_pretty_size(item.size_mb), icon="FILE_3D")
        box.label(text=item.job_id, icon="COPY_ID")
        if not item.blend_file:
            box.label(text="No project, the file was never saved", icon="INFO")
        if item.error:
            for i, line in enumerate(textwrap.wrap(item.error, 42)):
                box.label(text=line, icon="BLANK1")

        col = layout.column()
        col.enabled = not operators.is_fetching(item.job_id)
        col.operator("sb.ai_retopo_history_import", icon="IMPORT")


classes = (VIEW3D_PT_sb_ai_retopo, VIEW3D_UL_sb_ai_retopo_history,
           VIEW3D_PT_sb_ai_retopo_history)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
